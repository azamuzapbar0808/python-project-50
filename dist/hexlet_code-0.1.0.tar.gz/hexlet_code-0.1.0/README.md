### Hexlet tests and linter status:
[![Actions Status](https://github.com/azamuzapbar0808/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/azamuzapbar0808/python-project-50/actions)

# gendiff

## Установка


## Использование


## Пример работы
```bash
$ gendiff file1.json file2.json
{
  - follow: false
    host: hexlet.io
  - proxy: 123.234.53.22
  - timeout: 50
  + timeout: 20
  + verbose: true
}

Теперь `gendiff` работает и как CLI, и как библиотека 🚀
